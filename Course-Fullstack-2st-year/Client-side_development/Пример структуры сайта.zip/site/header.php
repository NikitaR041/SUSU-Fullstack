<!DOCTYPE html>
<html>
<head>
    <title>Главная страница</title>
    <link href="/style.css" rel="stylesheet" />
</head>
<body>
    <header>
        <div class="container">
            <div class="header">
                <div class="logo-container">
                    <img class="logo" src="/images/wordpress.png" alt="WordPress" />
                    <div>
                        Сайт о WordPress
                    </div>
                </div>
                <div>
                    <a href="/">Главная</a>
                    <a href="/test.php">Тест</a>
                </div>
                <div>
                    Аккаунт
                </div>
            </div>
        </div>
    </header>
    <main>
