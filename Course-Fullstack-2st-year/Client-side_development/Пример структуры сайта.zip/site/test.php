<?php
require 'header.php';
?>
<div class="container">
    <h1>Test</h1>
</div>
<?php
require 'footer.php';
