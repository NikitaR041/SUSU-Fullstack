<?php
require 'header.php';
?>
<div class="container">
    <h1>Hello world 1</h1>
    <p>
        abc
    </p>
    <p>
        def
    </p>
</div>
<?php
require 'footer.php';
